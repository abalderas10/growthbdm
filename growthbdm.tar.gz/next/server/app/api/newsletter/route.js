(()=>{var e={};e.id=5103,e.ids=[5103],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},84297:e=>{"use strict";e.exports=require("async_hooks")},55511:e=>{"use strict";e.exports=require("crypto")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},57075:e=>{"use strict";e.exports=require("node:stream")},4238:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>w,routeModule:()=>x,serverHooks:()=>v,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>g});var s={};t.r(s),t.d(s,{POST:()=>d});var i=t(42706),o=t(28203),a=t(45994),n=t(39187),p=t(58072),u=t(36408);let l=new p.u(process.env.RESEND_API_KEY),c=u.z.object({email:u.z.string().email()});async function d(e){try{let r=await e.json(),{email:t}=c.parse(r);return await l.emails.send({from:"Growth BDM <onboarding@resend.dev>",to:[t],subject:"\xa1Bienvenido al Newsletter de Growth BDM!",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #004b8d;">\xa1Bienvenido a Growth BDM!</h2>
          <div style="background-color: #f5f5f5; padding: 20px; border-radius: 8px;">
            <p>Gracias por suscribirte a nuestro newsletter. A partir de ahora recibir\xe1s:</p>
            <ul style="list-style-type: none; padding: 0;">
              <li style="margin: 10px 0;">✓ Actualizaciones sobre crecimiento empresarial</li>
              <li style="margin: 10px 0;">✓ Invitaciones a eventos exclusivos</li>
              <li style="margin: 10px 0;">✓ Tips y estrategias de expansi\xf3n</li>
              <li style="margin: 10px 0;">✓ Noticias sobre el mercado mexicano</li>
            </ul>
            <p style="margin-top: 20px;">
              Si tienes alguna pregunta, no dudes en contactarnos en 
              <a href="mailto:contacto@growthbdm.com" style="color: #004b8d;">contacto@growthbdm.com</a>
            </p>
          </div>
        </div>
      `}),n.NextResponse.json({success:!0})}catch(e){return console.error("Error en el endpoint de newsletter:",e),n.NextResponse.json({error:"Error processing subscription"},{status:400})}}let x=new i.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/newsletter/route",pathname:"/api/newsletter",filename:"route",bundlePath:"app/api/newsletter/route"},resolvedPagePath:"C:\\Users\\abald\\Dev_growthBDM\\GrowthBDM\\src\\app\\api\\newsletter\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:m,workUnitAsyncStorage:g,serverHooks:v}=x;function w(){return(0,a.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:g})}},96487:()=>{},78335:()=>{}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[5994,5452,9628],()=>t(4238));module.exports=s})();